package com.akshay.luminar;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LuminarApplicationTests {

	@Test
	void contextLoads() {
	}

}

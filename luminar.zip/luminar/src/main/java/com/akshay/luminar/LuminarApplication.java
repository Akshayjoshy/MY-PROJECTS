package com.akshay.luminar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LuminarApplication {

	public static void main(String[] args) {
		SpringApplication.run(LuminarApplication.class, args);
	}

}

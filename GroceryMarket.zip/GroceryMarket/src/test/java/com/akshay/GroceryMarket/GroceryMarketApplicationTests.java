package com.akshay.GroceryMarket;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GroceryMarketApplicationTests {

	@Test
	void contextLoads() {
	}

}

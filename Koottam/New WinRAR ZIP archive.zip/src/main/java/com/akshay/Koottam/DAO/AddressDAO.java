package com.akshay.Koottam.DAO;

import org.springframework.data.jpa.repository.JpaRepository;

import com.akshay.Koottam.Model.Address;

public interface AddressDAO extends JpaRepository<Address,Long>{

}

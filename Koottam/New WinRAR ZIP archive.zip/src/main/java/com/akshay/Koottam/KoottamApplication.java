package com.akshay.Koottam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KoottamApplication {

	public static void main(String[] args) {
		SpringApplication.run(KoottamApplication.class, args);
	}

}
